ANIME CARD VAULT PORTFOLIO — FINAL FIXED

Open index.html in a browser.

The existing portfolio architecture is preserved. This version fixes:
- A visible folder origin inside the vault overlay
- Cards releasing from the folder area
- Desktop six-card spread
- Mobile single-card swipe layout
- Card flip interaction
- Project preview launcher
- Reset after closing the vault

Replace YOUR NUMBER and YOUR EMAIL inside index.html.
Replace the placeholder files inside assets/ with your own GIF/PNG files.
